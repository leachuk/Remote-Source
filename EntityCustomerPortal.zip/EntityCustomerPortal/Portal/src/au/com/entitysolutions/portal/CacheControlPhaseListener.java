package au.com.entitysolutions.portal;

import au.com.entitysolutions.portal.view.EntityCustomViewHandler;

import java.util.Enumeration;
import java.util.logging.Logger;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;

public class CacheControlPhaseListener implements PhaseListener {
    private static final String SOURCE_CLASS = EntityCustomViewHandler.class.getCanonicalName();
    private static final Logger LOGGER = Logger.getLogger(SOURCE_CLASS);
    
    public CacheControlPhaseListener() {
        super();
    }

    public void afterPhase(PhaseEvent phaseEvent) {
    }

    public void beforePhase(PhaseEvent pPhaseEvent) {
        LOGGER.entering(SOURCE_CLASS, "beforePhase");
        FacesContext aFacesContext = pPhaseEvent.getFacesContext();        
        HttpServletResponse aResponse = (HttpServletResponse) aFacesContext.getExternalContext().getResponse();

        if (aFacesContext == null) {
            LOGGER.exiting(SOURCE_CLASS, "beforePhase, aFacesContext is null");
            return;
        }
        
        if (pPhaseEvent == null) {
            LOGGER.exiting(SOURCE_CLASS, "beforePhase, pPhaseEvent is null");
            return;
        }

        HttpServletRequest aRequest = (HttpServletRequest) aFacesContext.getExternalContext().getRequest();        
        if (aRequest == null) {
            LOGGER.exiting(SOURCE_CLASS, "beforePhase, aRequest is null");
            return;
        }
        
        String aReferer = aRequest.getHeader("Referer");
        if (aReferer == null) {
            LOGGER.exiting(SOURCE_CLASS, "beforePhase, aReferer is null");
            return;           
        }
        
        String aProtocol = aReferer.substring(0,5);
        if (aProtocol.equals("https")) {        
            aResponse.addHeader("Pragma", "no-cache");
            aResponse.addHeader("Cache-Control", "no-cache");
            aResponse.addHeader("Cache-Control", "no-store");
            aResponse.addHeader("Cache-Control", "must-revalidate");
            aResponse.setDateHeader("Expires", -1); // prevent caching at the proxy server
        }
        
        LOGGER.exiting(SOURCE_CLASS, "beforePhase");
    }

    public PhaseId getPhaseId() {
        return PhaseId.RENDER_RESPONSE;
    }
}
