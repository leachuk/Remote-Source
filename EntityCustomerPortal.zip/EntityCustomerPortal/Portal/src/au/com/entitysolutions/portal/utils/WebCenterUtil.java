package au.com.entitysolutions.portal.utils;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;

import oracle.adf.share.security.providers.jps.JpsSecurityContext;

public class WebCenterUtil {
    public WebCenterUtil() {
        super();
    }
    
    public static boolean isUserInRole(String roleName) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        Application app = ctx.getApplication();
        ExpressionFactory elFactory = app.getExpressionFactory();
        ELContext elContext = ctx.getELContext();
        ValueExpression valueExp = elFactory.createValueExpression(elContext,"#{securityContext}",Object.class); 
        Object object = valueExp.getValue(elContext);
        System.out.println(object);
        String[] roles = ((JpsSecurityContext)object).getUserRoles();                                                     
        System.out.println("Roles:" + roles);
        for(int i =0; roles != null && i < roles.length; i++ ) {
            System.out.println(roles[i]);    
        }
        valueExp = elFactory.createValueExpression(elContext,"#{securityContext.userInRole['" + roleName + "']}",Object.class); 
        object = valueExp.getValue(elContext);
        System.out.println(object);        
        return FacesContext.getCurrentInstance().getExternalContext().
                isUserInRole(roleName);
    }
    
    public static boolean isUserInRole(FacesContext context, String roleName) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        Application app = ctx.getApplication();
        ExpressionFactory elFactory = app.getExpressionFactory();
        ELContext elContext = ctx.getELContext();
        ValueExpression valueExp = elFactory.createValueExpression(elContext,"#{securityContext}",Object.class); 
        Object object = valueExp.getValue(elContext);
        System.out.println(object);
        String[] roles = ((JpsSecurityContext)object).getUserRoles();                                                     
        System.out.println("Roles:" + roles);
        for(int i =0; roles != null && i < roles.length; i++ ) {
            System.out.println(roles[i]);    
        }
        valueExp = elFactory.createValueExpression(elContext,"#{securityContext.userInRole['" + roleName + "']}",Object.class); 
        object = valueExp.getValue(elContext);
        System.out.println(object);        
        return context.getExternalContext().isUserInRole(roleName);
    }
}
