package au.com.entitysolutions.portal.utils;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This filter is a work-around an issue with WebCenter Portal. The page 
 * hierarchy is unavailable to an unauthenticated user and when a user attempts
 * to navigate to the pretty url (e.g. /faces/pages_home) webcenter throws a 404
 * instead of redirecting user to the login page.
 * Note that this may need to be extended to include other "public" pages. 
 */
public class WCUnAuthorizedUserFilter implements Filter {
    private FilterConfig _filterConfig = null;
    private String _loginPage = null;

    public void init(FilterConfig filterConfig) throws ServletException {
        _filterConfig = filterConfig;
        _loginPage = filterConfig.getInitParameter("loginPage");
    }

    public void destroy() {
        _filterConfig = null;
    }

    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException,
                                                   ServletException {
        final HttpServletRequest httpServletRequest =
            (HttpServletRequest)request;

        if (httpServletRequest.getUserPrincipal() == null &&
            !httpServletRequest.getRequestURI().endsWith("login.jspx")) {
            ((HttpServletResponse)response).sendRedirect(httpServletRequest.getContextPath() +
                                                         _loginPage);
        } else {            
            chain.doFilter(request, response);
        }
    }
}
