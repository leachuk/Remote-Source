package au.com.entitysolutions.portal.view;

import java.beans.Beans;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.faces.component.UIViewRoot;

import javax.faces.context.FacesContext;

import oracle.webcenter.navigationframework.NavigationResource;
import oracle.webcenter.portalframework.sitestructure.SiteStructure;
import oracle.webcenter.portalframework.sitestructure.SiteStructureContext;
import oracle.webcenter.portalframework.sitestructure.SiteStructureResource;
import oracle.webcenter.portalframework.sitestructure.SiteStructureUtils;
import oracle.webcenter.portalframework.sitestructure.handler.CustomViewHandler;

/**
 * Extend the custom view handler used by webcenter portal.
 */
public class EntityCustomViewHandler extends CustomViewHandler {
    private static final String SOURCE_CLASS = EntityCustomViewHandler.class.getCanonicalName();
    private static final Logger LOGGER = Logger.getLogger(SOURCE_CLASS);       
    public EntityCustomViewHandler(javax.faces.application.ViewHandler viewHandler) {
        super(viewHandler);
    }
    
    /*
    @Override
    public String getActionURL(FacesContext fctx, String viewId) {
        String urlStr = viewId;

        if (Beans.isDesignTime()) {
            return m_baseHandler.getActionURL(fctx, urlStr);
        }

        // Only perform the pretty url lookup if the request was from our
        // navigation processAction
        if (isRequestDrivenByNavigation(fctx)) {
            SiteStructure model =
                SiteStructureContext.getInstance().getCurrentModel();
            if (model != null) {
                SiteStructureResource resource = model.getCurrentSelection();
                if (resource != null) {
                    // Bug 11076967
                    // Only translate to pretty URL if the viewId is that of the resource.
                    // There is a usecase (bug 11076967) where the viewId is
                    // the login_success outcome in which case, we shouldn't touch it
                    String resourceViewId = findTargetViewId(fctx, resource);
                    if (resourceViewId != null &&
                        resourceViewId.equals(viewId))
                        urlStr = "/" + SiteStructureUtils.encodeUrl(resource.getPrettyUrl());
                }
            }
        }

        // Get the base handler to tag on anything else that might be needed
        // which includes the _adf.ctrl-state
        String ret = m_baseHandler.getActionURL(fctx, urlStr);

        return ret;
    }    
*/
    
    /**
     * Overridden createView method
     * @param context
     * @param pViewId
     * @return view root
     */
    public UIViewRoot createView(FacesContext context, String pViewId)
    {
        LOGGER.entering(SOURCE_CLASS, "createView");
        UIViewRoot vR =  null;
        if(pViewId.endsWith("homepage"))
        {
            LOGGER.finest("LANDING PAGE requested. Try with the first node in the site structure.");
            SiteStructure ss = getCurrentSiteStructure();
            List<NavigationResource> children = ss.getRootNode().getChildren();
            
            SiteStructureResource nodeToUse = null;                
            if(children != null && children.size() > 0) {
               SiteStructureResource firstChild  = (SiteStructureResource)children.get(0);      
               if(firstChild.isNavigable()) {
                   nodeToUse = firstChild;
               }
               else if(!firstChild.isNavigable() && firstChild.getChildCount() > 0) {
                   nodeToUse = (SiteStructureResource)firstChild.getChildren().get(0);
               }               
            }
            ss.setCurrentSelection(nodeToUse);
            pViewId = nodeToUse.getPrettyUrl();
            LOGGER.finest("create view with the new viewId:" + pViewId);
        }
        vR = super.createView(context, pViewId);
        LOGGER.exiting(SOURCE_CLASS, "createView");
        return vR;
    }
    
    /**
     * Convenience method to obtain the current site structure
     * @return current site structure
     */
    private SiteStructure getCurrentSiteStructure()
      {
        String METHOD_NAME = "getCurrentSiteStructure";
        LOGGER.entering(SOURCE_CLASS, METHOD_NAME);

        SiteStructureContext ctx = SiteStructureContext.getInstance();
        SiteStructure siteStructure = null;
        try
        {
          if (ctx != null)
            siteStructure = ctx.getCurrentModel();
        }
        catch (Exception e) {
          if (LOGGER.isLoggable(Level.FINE)) {
            LOGGER.fine(e.toString());
          }
        }

        LOGGER.exiting(SOURCE_CLASS, METHOD_NAME);
        return siteStructure;
      }
}
